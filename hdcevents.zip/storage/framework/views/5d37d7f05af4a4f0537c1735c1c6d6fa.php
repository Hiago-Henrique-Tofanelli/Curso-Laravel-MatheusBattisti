<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />

        <!-- Styles -->
        <style>
            body {
                font-family: 'Nunito';
            }
        </style>
       
    </head>
    <body>
        <h1>Algum título</h1>
        <?php if(10 > 5): ?>
        <p>A condição é true</p>
        <?php endif; ?>
        <p><?php echo e($nome); ?></p>
        <?php if($nome == "João"): ?>
        <p>O nome é João</p>
        <?php elseif($nome == "Pedro"): ?>
        <p>O nome é <?php echo e($nome); ?> e ele tem <?php echo e($idade); ?> anos, e trabalha como <?php echo e($profissao); ?></p>
        <?php else: ?> 
        <p>O nome não é João</p>
        <?php endif; ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\hdcevents-app\resources\views/welcome.blade.php ENDPATH**/ ?>